import os, sys
import time
os.system("start powershell Expand-Archive cicada.zip & ")
time.sleep(4)

os.system("start powershell cd cicada")
time.sleep(2)
os.system("start del  cicada.zip")

